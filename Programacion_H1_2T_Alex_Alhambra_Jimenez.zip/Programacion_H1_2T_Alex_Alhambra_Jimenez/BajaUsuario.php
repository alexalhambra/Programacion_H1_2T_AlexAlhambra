<!DOCTYPE html>
<html>
<head>
<title>Eliminar Usuario</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN6jIeHz" crossorigin="anonymous"></script>

<style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .table-container {
            max-width: 80%;
            margin: 50px auto;
        }

        .form-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
        }

        .form-footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }

        /* Estilo de la barra de navegación */
        .nav-tabs {
            border: none;
            border-bottom: 2px solid #ccc;
        }

        .nav-item {
            margin: 0 10px;
        }

        .nav-link {
            color: #555;
            font-weight: 500;
            text-transform: uppercase;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #007bff;
            text-decoration: none;
        }

        .nav-link.active {
            color: #ffffff;
            background-color: #007bff;
            border-color: #007bff;
        }

        .card-header {
            background-color: #f8f9fa;
        }

        /* Mejoras en la tabla */
        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            text-align: center;
            padding: 12px;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
</style>
</head>
<body>
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" aria-current="true" href="index.php">Planes y Paquetes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="formulario.php">Precios</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="suscripcion.php">Suscripción</a>
      </li>
            <li class="nav-item">
        <a class="nav-link" href="BajaUsuario.php">Baja Usuario</a>
      </li>
            <li>
            <li class="nav-item">
                <a class="nav-link" href="ModificarUsuario.php">Modificar Usuario</a>
      </li>
    </ul>
  </div>
</div>
    
    <h1>Eliminar Usuario</h1>
    <form action="" method="POST">
            <label for="email" class="form-label">Correo electrónico:</label>
            <input type="email" name="email" id="email" class="form-control" required>
        <button type="submit" class="btn btn-danger">Baja Usuario</button>
    </form>

    <?php
    // Conectamos a la base de datos
    include_once './conexion.php';
    $conn = new mysqli("localhost", "root", "campusfp", "streaming");

    if ($conn->connect_error) {
        echo 'Error de conexión: ' . $conn->connect_error . '</p>';
        exit();
    }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email'])) {
        // Obtener el email del formulario 
        $correo = $conn->real_escape_string($_POST['email']);

        
        // Consulta para eliminar el usuario
        $sql = "DELETE FROM usuarios WHERE correo = '$correo'";
        if ($conn->query($sql) === TRUE) {
            if ($conn->affected_rows > 0) {
                echo 'Usuario con correo <b>' . htmlspecialchars($correo) . '</b> eliminado existosamente.</p>';
            } else {
                echo 'No se encontró un usuario con ese correo.</p>';
            }
        } else {
            echo 'Error al eliminar el usuario: ' . $conn->error . '</p>';
        }
    } else {
        echo 'El campo "Correo Electrónico" es obligatorio.</p>';
    }
        // Buscas correo
        }else {
            echo 'Debe introducir un correo electrónico: ' . $conn->error . '</p>';
        }
   

    $conn->close();
    ?>

</body>
</html>
