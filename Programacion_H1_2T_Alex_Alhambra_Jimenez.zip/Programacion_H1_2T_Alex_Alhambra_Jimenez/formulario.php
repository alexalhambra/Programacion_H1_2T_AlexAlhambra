<!DOCTYPE html>
<html>
<head>
<title>Precios Usuario</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN6jIeHz" crossorigin="anonymous"></script>

<style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .table-container {
            max-width: 80%;
            margin: 50px auto;
        }

        .form-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
        }

        .form-footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }

        /* Estilo de la barra de navegación */
        .nav-tabs {
            border: none;
            border-bottom: 2px solid #ccc;
        }

        .nav-item {
            margin: 0 10px;
        }

        .nav-link {
            color: #555;
            font-weight: 500;
            text-transform: uppercase;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #007bff;
            text-decoration: none;
        }

        .nav-link.active {
            color: #ffffff;
            background-color: #007bff;
            border-color: #007bff;
        }

        .card-header {
            background-color: #f8f9fa;
        }

        /* Mejoras en la tabla */
        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            text-align: center;
            padding: 12px;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
</style>
</head>
<body>
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" aria-current="true" href="index.php">Planes y Paquetes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="formulario.php">Precios</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="suscripcion.php">Suscripción</a>
      </li>
            <li class="nav-item">
        <a class="nav-link" href="BajaUsuario.php">Baja Usuario</a>
      </li>
            <li>
            <li class="nav-item">
                <a class="nav-link" href="ModificarUsuario.php">Modificar Usuario</a>
      </li>
    </ul>
  </div>
</div>
    
  <div class="card-body">
    <div class="table-container">
        <h2 class="text-center mb-4">Precios de Planes y Paquetes</h2>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Tipo de Plan</th>
                    <th>Precio Mensual (€)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Plan Básico (1 dispositivo)</td>
                    <td>9,99 €</td>
                </tr>
                <tr>
                    <td>Plan Estándar (2 dispositivos)</td>
                    <td>13,99 €</td>
                </tr>
                <tr>
                    <td>Plan Premium (4 dispositivos)</td>
                    <td>17,99 €</td>
                </tr>
            </tbody>
        </table>

        <h3 class="text-center mt-4 mb-4">Precios de Paquetes Adicionales</h3>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Pack</th>
                    <th>Precio Mensual (€)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Deporte</td>
                    <td>6,99 €</td>
                </tr>
                <tr>
                    <td>Cine</td>
                    <td>7,99 €</td>
                </tr>
                <tr>
                    <td>Infantil</td>
                    <td>4,99 €</td>
                </tr>
            </tbody>
        </table>
    </div>

    <form action="" method="POST">
        <div class="form-container">
            <h1>Suscripción a Paquetes de Streaming</h1>
            <b>Nombre:</b> <input type="text" name="nombre" required>
            <br><br>
            <b>Apellido:</b> <input type="text" name="apellido" required>
            <br><br>
            <b>Email: </b> <input type="email" name="correo" required>
            <br><br>
            <b>Edad: </b><input type="number" name="edad" min="0" max="120" required>
            <br><br>
            <b>Plan Base:</b>
            <select name="planBase" id="planBase" required>              
                <option value="" disabled selected>Selecciona un Plan Base</option>
                    <option value="Básico">Básico</option>
                        <option value="Estándar">Estándar</option>
                            <option value="Premium">Premium</option>
            </select>
            <br><br>
            <!-- Selección de Paquetes -->
            <b>Paquetes:</b>
            <input type="checkbox" name="Pack_deporte" value="1"> Deporte
                <input type="checkbox" name="Pack_cine" value="1"> Cine
                    <input type="checkbox" name="Pack_infantil" value="1"> Infantil
            <br><br>
            <!-- Duración de la suscripción -->
            <b>Suscripción: </b>
            <select name="duracion">
                <option value="Mensual">Mensual</option>
                <option value="Anual">Anual</option>
            </select>
            <br><br>
            <!-- Botón de envío -->
            <button type="submit" class="btn btn-primary btn-lg">Registrar</button>
        </div>
    </form>
    
    <?php
    include './conexion.php';

    if ($conn->connect_error) {
        die('Error de Conexión (' . $conn->connect_errno . ') ' . $conexion->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $_REQUEST["nombre"];
        $apellido = $_REQUEST["apellido"];
        $correo = $_REQUEST["correo"];
        $edad = $_REQUEST["edad"];
        $planBase = $_REQUEST["planBase"];
        $Pack_deporte = isset($_REQUEST["Pack_deporte"]) ? 1 : 0;
        $Pack_cine = isset($_REQUEST["Pack_cine"]) ? 1 : 0;
        $Pack_infantil = isset($_REQUEST["Pack_infantil"]) ? 1 : 0;
        $duracion = $_REQUEST["duracion"];
        
        $sql = "INSERT INTO usuarios (nombre, apellido, correo, edad, planBase, Pack_deporte, Pack_cine, Pack_infantil, duracion) 
        VALUES ('$nombre', '$apellido', '$correo', '$edad', '$planBase', '$Pack_deporte', '$Pack_cine','$Pack_infantil','$duracion')";

        if ($conn->query($sql) === TRUE) {
            echo "<h3 style='color: green; text-align: center;'>Suscripción guardada con éxito.</h3>";
        } else {
            echo "<h3 style='color: red; text-align: center;'>Error al guardar la suscripción: " . $conn->error . "</h3>";
        }
    }
    ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
