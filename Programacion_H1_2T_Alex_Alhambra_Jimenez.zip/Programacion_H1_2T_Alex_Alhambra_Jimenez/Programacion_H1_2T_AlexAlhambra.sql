drop database streaming;
create database streaming;
use streaming;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    correo VARCHAR(100) UNIQUE,
    edad numeric,
    planBase VARCHAR(20),	
    Pack_deporte  boolean default 0,
    Pack_cine boolean default 0,
    Pack_infantil boolean default 0,
    duracion VARCHAR(10),
    precio_final DECIMAL(10, 2)
);
select * from Usuarios; 	

delete from Usuarios where id=11;
SHOW COLUMNS FROM usuarios;

