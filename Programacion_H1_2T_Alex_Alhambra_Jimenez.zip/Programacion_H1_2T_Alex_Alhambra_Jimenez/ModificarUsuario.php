<!DOCTYPE html>
<html>
<head>
<title>Modificar Usuario</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN6jIeHz" crossorigin="anonymous"></script>

<style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .table-container {
            max-width: 80%;
            margin: 50px auto;
        }

        .form-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
        }

        .form-footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }

        /* Estilo de la barra de navegación */
        .nav-tabs {
            border: none;
            border-bottom: 2px solid #ccc;
        }

        .nav-item {
            margin: 0 10px;
        }

        .nav-link {
            color: #555;
            font-weight: 500;
            text-transform: uppercase;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #007bff;
            text-decoration: none;
        }

        .nav-link.active {
            color: #ffffff;
            background-color: #007bff;
            border-color: #007bff;
        }

        .card-header {
            background-color: #f8f9fa;
        }

        /* Mejoras en la tabla */
        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            text-align: center;
            padding: 12px;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
</style>
</head>
<body>
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" aria-current="true" href="index.php">Planes y Paquetes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="formulario.php">Precios</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="suscripcion.php">Suscripción</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="BajaUsuario.php">Baja Usuario</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ModificarUsuario.php">Modificar Usuario</a>
      </li>
    </ul>
  </div>
</div>

<div class="container mt-4">
    <form method="POST" class="form-container">
        <h1 class="text-center">Ingrese Usuario a buscar</h1>
        <div class="mb-3">
            <label for="email" class="form-label"><b>Email:</b></label>
            <input type="email" class="form-control" name="correo" id="correo" required>
        </div>
        <button type="submit" name="buscar" class="btn btn-primary w-100">Buscar</button>
    </form>
</div>

<?php

include './conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["buscar"])) {
    $correo = $_POST["correo"];
    $conn = new mysqli("localhost", "root", "campusfp", "streaming");

    if ($conn->connect_error) {
        die('<div class="text-danger text-center">Error (' . $conn->connect_errno . ') ' . $conn->connect_error . '</div>');
    }

    $sql = "SELECT * FROM usuarios WHERE correo = '$correo'";
    $muestra = $conn->query($sql);

    if ($muestra && $muestra->num_rows > 0) {
        $row = $muestra->fetch_assoc();

        $nombre = $row['nombre'] ?? '';
        $apellido = $row['apellido'] ?? '';
        $correo = $row['correo'] ?? '';
        $edad = $row['edad'] ?? '';
        $planBase = $row['planBase'] ?? '';
        $duracion = $row['duracion'] ?? '';

        $Pack_deporte = isset($row['Pack_deporte']) && $row['Pack_deporte'] == 1 ? 'SI' : 'NO';
        $Pack_cine = isset($row['Pack_cine']) && $row['Pack_cine'] == 1 ? 'SI' : 'NO';
        $Pack_infantil = isset($row['Pack_infantil']) && $row['Pack_infantil'] == 1 ? 'SI' : 'NO';

        // Mostrar datos correctamente
        echo "<div class='table-container'>
                <h2 class='text-center'>Detalles del Usuario</h2>
                <table class='table table-striped'>
                    <tr><td><b>Nombre:</b></td><td>{$nombre}</td></tr>
                    <tr><td><b>Apellido:</b></td><td>{$apellido}</td></tr>
                    <tr><td><b>Correo:</b></td><td>{$correo}</td></tr>
                    <tr><td><b>Edad:</b></td><td>{$edad}</td></tr>
                    <tr><td><b>Plan Contratado:</b></td><td>{$planBase}</td></tr>
                    <tr><td><b>Duración:</b></td><td>{$duracion}</td></tr>
                    <tr><td><b>Paquetes Adicionales:</b></td>
                        <td>Deporte: {$Pack_deporte}, Cine: {$Pack_cine}, Infantil: {$Pack_infantil}</td>
                    </tr>
                </table>
              </div>";

        // Mostrar formulario de actualización
        echo "<form method='POST' class='form-container'>
                <h1 class='text-center'>Modificar Usuario</h1>
                <div class='mb-3'>
                    <label for='correo' class='form-label'><b>Correo:</b></label>
                    <input type='email' class='form-control' name='correo' value='{$correo}' readonly>
                </div>
                <div class='mb-3'>
                    <label for='nombre' class='form-label'><b>Nombre:</b></label>
                    <input type='text' class='form-control' name='nombre' value='{$nombre}' required>
                </div>
                <div class='mb-3'>
                    <label for='apellido' class='form-label'><b>Apellido:</b></label>
                    <input type='text' class='form-control' name='apellido' value='{$apellido}' required>
                </div>
                <div class='mb-3'>
                    <label for='planBase' class='form-label'><b>Plan:</b></label>
                    <select class='form-control' name='planBase' required>
                        <option value='Básico' " . ($planBase == 'Básico' ? 'selected' : '') . ">Básico</option>
                        <option value='Estandar' " . ($planBase == 'Estandar' ? 'selected' : '') . ">Estandar</option>
                        <option value='Premium' " . ($planBase == 'Premium' ? 'selected' : '') . ">Premium</option>
                    </select>
                </div>
                <div class='form-check'>
                    <input type='checkbox' class='form-check-input' name='Pack_deporte' $Pack_deporte>
                    <label class='form-check-label' for='Pack_deporte'><b>Pack Deporte</b></label>
                </div>
                <div class='form-check'>
                    <input type='checkbox' class='form-check-input' name='Pack_cine' $Pack_cine>
                    <label class='form-check-label' for='Pack_cine'><b>Pack Cine</b></label>
                </div>
                <div class='form-check'>
                    <input type='checkbox' class='form-check-input' name='Pack_infantil' $Pack_infantil>
                    <label class='form-check-label' for='Pack_infantil'><b>Pack Infantil</b></label>
                </div>
                <button type='submit' name='actualizar' class='btn btn-primary w-100'>Actualizar</button>
              </form>";
    } else {
        echo "<h2 class='text-center text-danger'>No se encontraron resultados para el correo ingresado.</h2>";
    }

    $conn->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["actualizar"])) {
    $conn = new mysqli("localhost", "root", "campusfp", "streaming");

    if ($conn->connect_error) {
        die('Error de Conexión (' . $conn->connect_errno . ') ' . $conn->connect_error);
    }

    $correo = $_POST["correo"] ?? '';
    $nombre = $_POST["nombre"] ?? '';
    $apellido = $_POST["apellido"] ?? '';
    $planBase = $_POST["planBase"] ?? '';
    $Pack_deporte = isset($_POST["Pack_deporte"]) ? 1 : 0;
    $Pack_cine = isset($_POST["Pack_cine"]) ? 1 : 0;
    $Pack_infantil = isset($_POST["Pack_infantil"]) ? 1 : 0;

    $precios_plan = ["Básico" => 9.99, "Estandar" => 13.99, "Premium" => 17.99];
    $precios_pack = ["Deporte" => 6.99, "Cine" => 7.99, "Infantil" => 4.99];

    $precio_plan_base = $precios_plan[$planBase] ?? 0;
    $precio_final_paquetes = 
        ($Pack_deporte * $precios_pack["Deporte"]) + 
        ($Pack_cine * $precios_pack["Cine"]) + 
        ($Pack_infantil * $precios_pack["Infantil"]);

    $precio_final = $precio_plan_base + $precio_final_paquetes;

    $sql = "UPDATE usuarios SET 
                nombre = '$nombre', 
                apellido = '$apellido', 
                planBase = '$planBase', 
                Pack_deporte = '$Pack_deporte', 
                Pack_cine = '$Pack_cine', 
                Pack_infantil = '$Pack_infantil',
                precio_final = '$precio_final'
            WHERE correo = '$correo'";

    if ($conn->query($sql)) {
        if ($conn->affected_rows > 0) {
            echo "<h2 class='text-success'>Usuario actualizado correctamente.</h2>";
        } else {
            echo "<h2 class='text-warning'>No se realizó ningún cambio. Verifica que el correo exista.</h2>";
        }
    } else {
        echo "<h2 class='text-danger'>Error al actualizar: " . $conn->error . "</h2>";
    }

    $conn->close();
}
?>



</body>
</html>
        