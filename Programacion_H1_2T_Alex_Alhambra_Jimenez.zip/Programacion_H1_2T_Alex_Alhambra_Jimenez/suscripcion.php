<!DOCTYPE html>
<html>
<head>
<title>Suscripcion Usuario</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN6jIeHz" crossorigin="anonymous"></script>

<style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .table-container {
            max-width: 80%;
            margin: 50px auto;
        }

        .form-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
        }

        .form-footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }

        /* Estilo de la barra de navegación */
        .nav-tabs {
            border: none;
            border-bottom: 2px solid #ccc;
        }

        .nav-item {
            margin: 0 10px;
        }

        .nav-link {
            color: #555;
            font-weight: 500;
            text-transform: uppercase;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #007bff;
            text-decoration: none;
        }

        .nav-link.active {
            color: #ffffff;
            background-color: #007bff;
            border-color: #007bff;
        }

        .card-header {
            background-color: #f8f9fa;
        }

        /* Mejoras en la tabla */
        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            text-align: center;
            padding: 12px;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
</style>
</head>
<body>
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" aria-current="true" href="index.php">Planes y Paquetes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="formulario.php">Precios</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="suscripcion.php">Suscripción</a>
      </li>
            <li class="nav-item">
        <a class="nav-link" href="BajaUsuario.php">Baja Usuario</a>
      </li>
            <li>
            <li class="nav-item">
                <a class="nav-link" href="ModificarUsuario.php">Modificar Usuario</a>
      </li>
    </ul>
  </div>
</div>
    
    
     
   
<?php
// Conexión a la base de datos
$conn = new mysqli("localhost", "root", "campusfp", "streaming");

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Consulta para obtener todos los registros de la tabla 'usuarios'
$sql = "SELECT * FROM usuarios"; 
$usuariosResult = $conn->query($sql); // Ejecutamos la consulta

// Verificamos si hay resultados
if ($usuariosResult->num_rows > 0) {
    // Si hay resultados, los mostramos en una tabla HTML
    echo "<table border='1' style='width: 100%; border-collapse: collapse;'>";
    echo "<tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Correo</th>
            <th>Edad</th>
            <th>Plan Contratado</th>
            <th>Pack Deporte</th>
            <th>Pack Cine</th>
            <th>Pack Infantil</th>
            <th>Duración</th>

          </tr>";
    

    // Mostramos los datos en filas
    while ($row = $usuariosResult->fetch_assoc()) {
        echo "<tr>";
echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['nombre'] . "</td>";
echo "<td>" . $row['apellido'] . "</td>";
echo "<td>" . $row['correo'] . "</td>";
echo "<td>" . $row['edad'] . "</td>";
echo "<td>" . $row['planBase'] . "</td>";
echo "<td>" . ($row['Pack_deporte'] ? 'Sí' : 'No') . "</td>";
echo "<td>" . ($row['Pack_cine'] ? 'Sí' : 'No') . "</td>";
echo "<td>" . ($row['Pack_infantil'] ? 'Sí' : 'No') . "</td>";
echo "<td>" . $row['duracion'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    // Si no hay registros, mostramos un mensaje
    echo "<p>No hay registros disponibles.</p>";
}

// Cerrar la conexión
$conn->close();
?>

<a href="index.php" class="btn btn-primary mt-3">Volver al inicio</a>
</body>
</html>
